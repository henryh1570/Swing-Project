/***************************************************************
* file: CheckWord.java
* author: Luis Cortes, Oscar Hernandez, Henry Hu, Y-Uyen La, and An Le 
* class: CS 245 - Programming Graphical User Interfaces
*
* assignment: Swing Project v1.0
* date last modified: 1/18/2017
*
* purpose: This program is a game of Hangman where users are allowed up to 6 tries
* to guess the word correctly. 
*
****************************************************************/ 
package hangman;

import java.io.Serializable;

/**
 *class: Score
 * purpose: This class creates the "Score" to be used in the "ScoreSerializer" class
 */
public class Score implements Serializable {
    private final String NAME;
    private final int SCORE;
    
    //constructor: Score
    //purpose: This creates the Score object
    public Score(String name, int score) {
        NAME = name;
        SCORE = score;
    }

    //method: getName
    //purpose: This returns the name of the scorer
    public String getName() {
        return NAME;
    }

    //method: getScore
    //purpose: This returns the score
    public int getScore() {
        return SCORE;
    }
}
